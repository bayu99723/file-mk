<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Regcasis</title>
    <link rel="stylesheet" type="text/css" href="Assets/Style/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="Assets/Style/style.css">
</head>

<body>
    <!-- ======= Hero Section ======= -->
    <section id="hero" class="d-flex align-items-center">

        <div class="container">
            <div class="row">
                <div class="col-lg-6 d-flex flex-column justify-content-center pt-4 pt-lg-0 order-2 order-lg-1"
                    data-aos="fade-up" data-aos-delay="200">
                    <h1>WELCOME</h1>
                    <h2>Website Registration Data Siswa Baru</h2>
                </div>
                <div class="col-lg-6 order-1 order-lg-2 hero-img" data-aos="zoom-in" data-aos-delay="200">
                    <img src="Assets/Image/school.png" class="img-fluid animated" alt="">
                </div>
            </div>
        </div>

    </section>
    <!-- End Hero -->

    <!-- Info Section -->
    <section id="info" class="info section-bg">
        <div class="container-fluid" data-aos="fade-up">
            <div class="row">
                <div class="col-lg-7 d-flex flex-column justify-content-center align-items-stretch  order-2 order-lg-1">
                    <div class="content">
                        <h3>About<strong>STATE VOCATIONAL SCHOOL 9 MEDAN</strong></h3>
                        <p>
                        SMKN 9 Medan adalah sebuah sekolah SMK negeri yang yang lokasinya berada di Jl. Patriot No. 20 A Medan, Kota Medan.
                        SMK negeri ini berdiri sejak 1997. 
                        Pada saat ini SMK Negeri 9 Medan memakai panduan kurikulum belajar pemerintah yaitu SMK 2013 REV. Multimedia. 
                        SMKN 9 Medan dibawah komando seorang kepala sekolah dengan nama M.SOFA.ANANDA, SPD.MPD.
                        Dan juga di SMK ini terdapat 6 jurusan Kopentensi Keahlian yaitu, SOCIAL CARE, REKAYASA PERANGKAT LUNAK(RPL), TEKNIK JARINGAN DAN KOMPUTER(TKJ),
                        MULTIMEDIA(MM), ANIMASI, DAN DESAIN KOMUNIKASI VISUAL(DKV).
                        Dan memliki bebarapa ekskul diantaranya, ESPORT, FUTSAL, BAND, PASKIBRA, DAN ROHIS. 
                    <br>
                        DAFTARKAN SEGERA DIRI ANDA DENGAN MENGISI FORM REGISTRASI DIBAWAH INI YAA👇🏻👇🏻👇🏻👇🏻. 
                        GOOD LUCK ^⁠_⁠^ 
                        </p>
                    </div>
                </div>
                <div class="col-lg-5 align-items-stretch order-1 order-lg-2 img"
                    style='background-image: url("Assets/Image/info2.jpeg");' data-aos="zoom-in" data-aos-delay="150">
                    &nbsp;</div>
            </div>
        </div>
    </section>
    <!-- End Info -->
    <!-- ======= Formulir Section ======= -->
    <section id="formulir" class="formulir">
        <div class="container" data-aos="fade-up">
            <div class="section-title">
                <h2>Regisration</h2>
                <p></p>
            </div>
            <div class="row">
                <div class="col-lg-12 mt-5 mt-lg-0 d-flex align-items-stretch">
                    <form action="Config/crud.php" method="post" role="form" class="php-email-form" enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="nama">Nama</label>
                            <input type="text" name="nama" class="form-control" id="name" required>
                        </div>
                        <div class="form-group">
                            <label for="TTL">Tempat Tanggal Lahir</label>
                            <input type="text" name="TTL" class="form-control" id="TTL" required>
                        </div>
                        <div class="form-group">
                            <label for="warga">Warga Negara</label>
                            <input type="text" name="warga" class="form-control" id="warga" required>
                        </div>
                        <div class="form-group">
                            <label for="alamat">Alamat</label>
                            <input type="text" name="alamat" class="form-control" id="alamat" required>
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" class="form-control" name="email" id="email" required>
                        </div>
                        <div class="form-group">
                            <label for="nomor">Nomor HP</label>
                            <input type="text" name="nomor" class="form-control" id="nomor" required>
                        </div>
                        <div class="form-group">
                            <label for="asal">Asal Sekolah</label>
                            <input type="text" name="asal" class="form-control" id="asal" required>
                        </div>
                        <div class="form-group">
                            <label for="nama_ayah">Nama Ayah</label>
                            <input type="text" name="nama_ayah" class="form-control" id="nama_ayah" required>
                        </div>
                        <div class="form-group">
                            <label for="nama_ibu">Nama Ibu</label>
                            <input type="text" name="nama_ibu" class="form-control" id="nama_ibu" required>
                        </div>
                        <div class="form-group">
                            <label for="penghasilan">Penghasilan Ortu</label>
                            <input type="text" name="penghasilan" class="form-control" id="penghasilan" required>
                        </div>
                        <label class="form-label"> Pas Foto Peserta Didik </label>
                        <input type="file" class="form-control" name="foto" required>
                        <div class="text-center"><button type="submit" name="daftar" class="btn btn-primary mt-2">Daftar</button></div>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <!-- End Formulir Section -->
</body>

</html>