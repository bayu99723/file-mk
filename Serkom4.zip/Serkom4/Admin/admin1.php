<?php
session_start();
include '../Config/koneksi.php';

if ($_SESSION['status'] != 'login') {
    echo "<script>
    alert('Anda Belum Login!');
    location.href='home.php';
  </script>";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../Assets/Style/css/bootstrap.min.css">
    <title>Admin</title>
    <style>
        body {
            background: linear-gradient(rgba(40, 58, 90, 0.9), rgba(40, 58, 90, 0.9)), url("../Assets/Image/Depan-Aula.jpeg") fixed center center;
            background-size: cover;
        }

        #floatingButton {
            position: fixed;
            bottom: 20px;
            right: 20px;
            padding: 10px 20px;
            background-color: black;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark sticky-top " style="background-color: #000000">
        <div class="container">
            <a class="navbar-brand" href="admin.php">
                <h4>Data Registrasi Siswa Baru</h4>
            </a>
            <div class="collapse navbar-collapse mt-2" id="navbarNavAltMarkup">
                <div class="navbar-nav me-auto">
                </div>
                <a href="../config/logout.php" class="btn btn-outline-danger m-1">Keluar</a>
            </div>
        </div>
    </nav>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card mt-4">
                    <div class="card-header"><strong>Data Siswa</strong></div>
                    <div class="card-body">
                        <table class="table" cellpadding="7">
                            <thead>
                                <tr>
                                    <th> No </th>
                                    <th> Foto </th>
                                    <th> Data Siswa </th>
                                    <th colspan="3"> Aksi </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $no = 1;
                                $sql = mysqli_query($koneksi, "SELECT * FROM table_data_siswa ");
                                while ($data = mysqli_fetch_array($sql)) {
                                    ?>
                                    <tr>
                                        <td rowspan="10">
                                            <?php echo $no++ ?>
                                        </td>
                                        <td rowspan="10"><img src="../Assets/Data/<?php echo $data['Foto'] ?>" width="250"
                                                height="300"></td>
                                        <td>
                                            Nama : <?php echo $data['Nama'] ?>
                                        </td>
                                        <td>
                                            <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                                data-bs-target="#edit<?php echo $data['id'] ?>"> Edit </button>
                                            <div class="modal fade" id="edit<?php echo $data['id'] ?>" tabindex="-1"
                                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h1 class="modal-title fs-5" id="exampleModalLabel"> Edit Data
                                                            </h1>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                                aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <form action="../Config/crud.php" method="POST"
                                                                enctype="multipart/form-data">
                                                                <input type="hidden" name="id"
                                                                    value="<?php echo $data['id'] ?>">
                                                                <label class="form-label"> Nama </label>
                                                                <input type="text" name="Nama"
                                                                    value="<?php echo $data['Nama'] ?>" class="form-control"
                                                                    required>
                                                                <label class="form-label"> Tempat Tanggal Lahir </label>
                                                                <input type="text" name="TTL"
                                                                    value="<?php echo $data['TTL'] ?>" class="form-control"
                                                                    required>
                                                                <label class="form-label"> Warga Negara </label>
                                                                <input type="text" name="Warga"
                                                                    value="<?php echo $data['Warga_negara'] ?>"
                                                                    class="form-control" required>
                                                                <label class="form-label"> Alamat </label>
                                                                <input type="text" name="Alamat"
                                                                    value="<?php echo $data['Alamat'] ?>"
                                                                    class="form-control" required>
                                                                <label class="form-label"> Email </label>
                                                                <input type="text" name="Email"
                                                                    value="<?php echo $data['Email'] ?>"
                                                                    class="form-control" required>
                                                                <label class="form-label"> Nomor HP </label>
                                                                <input type="text" name="Nomor"
                                                                    value="<?php echo $data['Nomor_hp'] ?>"
                                                                    class="form-control" required>
                                                                <label class="form-label"> Asal Sekolah </label>
                                                                <input type="text" name="Asal"
                                                                    value="<?php echo $data['Asal_SMP'] ?>"
                                                                    class="form-control" required>
                                                                <label class="form-label"> Nama Ayah</label>
                                                                <input type="text" name="Nama_Ayah"
                                                                    value="<?php echo $data['Nama_Ayah'] ?>"
                                                                    class="form-control" required>
                                                                <label class="form-label"> Nama Ibu</label>
                                                                <input type="text" name="Nama_Ibu"
                                                                    value="<?php echo $data['Nama_Ibu'] ?>"
                                                                    class="form-control" required>
                                                                <label class="form-label"> Penghasilan Orang Tua </label>
                                                                <input type="text" name="Penghasilan"
                                                                    value="<?php echo $data['Penghasilan_Ortu'] ?>"
                                                                    class="form-control" required>
                                                                <label class="form-label"> Foto </label>
                                                                <div class="row">
                                                                    <div class="col-md-4">
                                                                        <img src="../Assets/Data/<?php echo $data['Foto'] ?>"
                                                                            width="100">
                                                                    </div>
                                                                    <div class="col-md-8">
                                                                        <label class="form-label"> Ganti File </label>
                                                                        <input type="file" class="form-control" name="foto">
                                                                    </div>
                                                                </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="submit" name="edit" class="btn btn-primary"> Edit
                                                                Data </button>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <button type="button" class="btn btn-danger" data-bs-toggle="modal"
                                                data-bs-target="#hapus<?php echo $data['id'] ?>"> Hapus </button>
                                            <div class="modal fade" id="hapus<?php echo $data['id'] ?>" tabindex="-1"
                                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h1 class="modal-title fs-5" id="exampleModalLabel"> Hapus Data
                                                            </h1>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                                aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <form action="../Config/crud.php" method="POST">
                                                                <input type="hidden" name="id"
                                                                    value="<?php echo $data['id'] ?>">
                                                                Apakah anda yakin ingin menghapus data? <strong>
                                                                </strong>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="submit" name="hapus" class="btn btn-primary">
                                                                Hapus Data </button>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>

                                    </tr>
                                    <tr>
                                        <td>
                                            Tempat/Tanggal Lahir : <?php echo $data['TTL'] ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            Warga : <?php echo $data['Warga_negara'] ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            Alamat : <?php echo $data['Alamat'] ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            Email : <?php echo $data['Email'] ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            Nomor HP : <?php echo $data['Nomor_hp'] ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            Asal Sekolah : <?php echo $data['Asal_SMP'] ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            Nama Ayah : <?php echo $data['Nama_Ayah'] ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            Nama Ibu : <?php echo $data['Nama_Ibu'] ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            Penghasilan Ortu : <?php echo $data['Penghasilan_Ortu'] ?>
                                        </td>
                                    </tr>

                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <a href="../Config/cetak.php" class="button" id="floatingButton" target="_blank">Cetak Data</a>
    <script type="text/javascript" src="../Assets/Style/js/bootstrap.min.js"></script>
</body>

</html>