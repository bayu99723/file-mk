-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 28, 2024 at 07:17 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `serkom`
--

-- --------------------------------------------------------

--
-- Table structure for table `table_admin`
--

CREATE TABLE `table_admin` (
  `id_admin` int(11) NOT NULL,
  `username` varchar(225) NOT NULL,
  `password` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `table_admin`
--

INSERT INTO `table_admin` (`id_admin`, `username`, `password`) VALUES
(1, 'admin', 'admin123');

-- --------------------------------------------------------

--
-- Table structure for table `table_data_siswa`
--

CREATE TABLE `table_data_siswa` (
  `id` int(11) NOT NULL,
  `Nama` varchar(255) NOT NULL,
  `TTL` varchar(255) NOT NULL,
  `Warga_negara` varchar(225) NOT NULL,
  `Alamat` varchar(225) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Nomor_hp` varchar(13) NOT NULL,
  `Asal_SMP` varchar(225) NOT NULL,
  `Nama_Ayah` varchar(225) NOT NULL,
  `Nama_Ibu` varchar(225) NOT NULL,
  `Penghasilan_Ortu` varchar(225) NOT NULL,
  `Foto` varchar(225) NOT NULL,
  `tanggal_unggah` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `table_data_siswa`
--

INSERT INTO `table_data_siswa` (`id`, `Nama`, `TTL`, `Warga_negara`, `Alamat`, `Email`, `Nomor_hp`, `Asal_SMP`, `Nama_Ayah`, `Nama_Ibu`, `Penghasilan_Ortu`, `Foto`, `tanggal_unggah`) VALUES
(7, 'Nazwa Yumna Zharifah', 'Medan,05 September 2006', 'Indonesia', 'Jln.Jalan', 'nazwa@gmail.com', '081243657698', 'SMP', 'Ayah', 'Bunda', 'Rp.7.000.000,00', 'Nazwa Yumna Zharifah-Nazwa Yumna Zharifah.jpeg', '2024-04-28');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `table_admin`
--
ALTER TABLE `table_admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indexes for table `table_data_siswa`
--
ALTER TABLE `table_data_siswa`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `table_admin`
--
ALTER TABLE `table_admin`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `table_data_siswa`
--
ALTER TABLE `table_data_siswa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
