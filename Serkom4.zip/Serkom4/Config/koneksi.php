<?php 
$hostname = 'localhost';
$userdb = 'root';
$passdb = '';
$namedb = 'serkom4';

$koneksi = mysqli_connect($hostname,$userdb,$passdb,$namedb);



?>