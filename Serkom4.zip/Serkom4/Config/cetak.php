<?php
session_start();
include '../Config/koneksi.php';

if ($_SESSION['status'] != 'login') {
    echo "<script>
    alert('Anda Belum Login!');
    location.href='home.php';
  </script>";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../Assets/Style/css/bootstrap.min.css">
    <title>Admin</title>
</head>

<body>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card mt-4">
                    <div class="card-header"><strong>Data Siswa</strong></div>
                    <div class="card-body">
                        <table class="table" cellpadding="7">
                            <thead>
                                <tr>
                                    <th> No </th>
                                    <th> Foto </th>
                                    <th> Data Siswa </th>
                                    <th colspan="2"> Aksi </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $no = 1;
                                $sql = mysqli_query($koneksi, "SELECT * FROM table_data_siswa ");
                                while ($data = mysqli_fetch_array($sql)) {
                                    ?>
                                    <tr>
                                        <td rowspan="10">
                                            <?php echo $no++ ?>
                                        </td>
                                        <td rowspan="10"><img src="../Assets/Data/<?php echo $data['Foto'] ?>" width="250"
                                                height="300"></td>
                                        <td>
                                            Nama : <?php echo $data['Nama'] ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            Tempat/Tanggal Lahir : <?php echo $data['TTL'] ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            Warga : <?php echo $data['Warga_negara'] ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            Alamat : <?php echo $data['Alamat'] ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            Email : <?php echo $data['Email'] ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            Nomor HP : <?php echo $data['Nomor_hp'] ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            Asal Sekolah : <?php echo $data['Asal_SMP'] ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            Nama Ayah : <?php echo $data['Nama_Ayah'] ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            Nama Ibu : <?php echo $data['Nama_Ibu'] ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            Penghasilan Ortu : <?php echo $data['Penghasilan_Ortu'] ?>
                                        </td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script type="text/javascript" src="../Assets/Style/js/bootstrap.min.js"></script>
    <script>
        window.print();
    </script>
</body>

</html>