<?php 
session_start();
include 'koneksi.php';

$username = $_POST['username'];
$password = md5($_POST['password']);

$sql = mysqli_query($koneksi, "SELECT * FROM table_admin WHERE username='$username' AND password='$password' ");

$cek = mysqli_num_rows($sql);
/*Aksi Login */
if ($cek > 0){
    $data = mysqli_fetch_array($sql);

    $_SESSION['username'] = $data['username'];
    $_SESSION['status'] = 'login';
    echo "<script>
    alert('Login berhasil');
    location.href='../Admin/admin.php';
    
    </script>";
}else{
    echo "<script>
    alert('Username atau Passwordnya salah!');
    location.href='../Admin/home.php';
    
    </script>";
}

?>