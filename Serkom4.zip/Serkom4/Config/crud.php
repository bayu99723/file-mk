<?php
session_start();
include 'koneksi.php';

if (isset($_POST['daftar'])) {
    $nama = $_POST['nama'];
    $TTL = $_POST['TTL'];
    $warga = $_POST['warga'];
    $alamat = $_POST['alamat'];
    $email = $_POST['email'];
    $nomor = $_POST['nomor'];
    $asal = $_POST['asal'];
    $nama_ayah = $_POST['nama_ayah'];
    $nama_ibu = $_POST['nama_ibu'];
    $penghasilan = $_POST['penghasilan'];
    $foto = $_FILES['foto']['name'];
    $tmp = $_FILES['foto']['tmp_name'];
    $lokasi = '../Assets/Data/';
    $namafoto = $nama . '-' . $foto;
    $tanggalunggah = date('Y-m-d');

    move_uploaded_file($tmp, $lokasi . $namafoto);

    $sql = mysqli_query($koneksi, "INSERT INTO table_data_siswa VALUES('','$nama','$TTL','$warga','$alamat','$email','$nomor','$asal','$nama_ayah','$nama_ibu','$penghasilan','$namafoto','$tanggalunggah')");

    echo "<script>
    alert('Data berhasil di simpan!');
    location.href='../index.php';
    </script>";
}

if (isset($_POST['edit'])) {
    $id = $_POST['id'];
    $nama = $_POST['Nama'];
    $TTL = $_POST['TTL'];
    $warga = $_POST['Warga'];
    $alamat = $_POST['Alamat'];
    $email = $_POST['Email'];
    $nomor = $_POST['Nomor'];
    $asal = $_POST['Asal'];
    $nama_ayah = $_POST['Nama_Ayah'];
    $nama_ibu = $_POST['Nama_Ibu'];
    $penghasilan = $_POST['Penghasilan'];
    $foto = $_FILES['foto']['name'];
    $tmp = $_FILES['foto']['tmp_name'];
    $lokasi = '../Assets/Data/';
    $namafoto = $nama . '-' . $foto;
    $tanggalunggah = date('Y-m-d');

    if ($foto == null) {

        $sql = mysqli_query($koneksi, "UPDATE table_data_siswa SET 
        Nama='$nama', 
        TTL='$TTL', 
        Warga_Negara='$warga', 
        Alamat='$alamat', 
        Email='$email', 
        Nomor_hp='$nomor',
        Asal_SMP='$asal', 
        Nama_Ayah='$nama_ayah', 
        Nama_Ibu='$nama_ibu',
        Penghasilan_Ortu='$penghasilan' WHERE id='$id'");

    } else {
        $query = mysqli_query($koneksi, "SELECT * FROM table_data_siswa WHERE id='$id'");
        $data = mysqli_fetch_array($query);
        if (is_file('../Assets/Data/' . $data['Foto'])) {
            unlink('../assets/Data/' . $data['Foto']);
        }
        move_uploaded_file($tmp, $lokasi . $namafoto);
        $sql = mysqli_query($koneksi, "UPDATE table_data_siswa SET 
        Nama='$nama', 
        TTL='$TTL', 
        Warga_Negara='$warga', 
        Alamat='$alamat', 
        Email='$email', 
        Nomor_hp='$nomor',
        Nama='$asal', 
        Nama_Ayah='$nama_ayah', 
        Nama_Ibu='$nama_ibu',
        Penghasilan_Ortu='$penghasilan',
        Foto ='$namafoto'
        WHERE id='$id'");
    }
    echo "<script>
    alert('Data berhasil di diperbaharui!');
    location.href='../Admin/admin.php';
    </script>";
}
if (isset($_POST['hapus'])) {
    $id = $_POST['id'];
    $query = mysqli_query($koneksi, "SELECT * FROM table_data_siswa WHERE id='$id'");
    $data = mysqli_fetch_array($query);
    if (is_file('../Assets/Data/' . $data['Foto'])) {
        unlink('../assets/Data/' . $data['Foto']);
    }
    $sql = mysqli_query($koneksi, "DELETE FROM table_data_siswa WHERE id='$id'");
    echo "<script>
    alert('Data berhasil dihapus!');
    location.href='../Admin/admin.php';
    </script>";
}