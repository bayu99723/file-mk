<?php 
include 'koneksi.php';

$username = $_POST['username'];
$password = md5($_POST['password']);

$sql = mysqli_query($koneksi, "INSERT INTO table_admin VALUES('','$username','$password')");

if($sql){
    echo "<script>
    alert('Pendaftaran akun berhasil,silahkan melakukan login');
    location.href='../home.php';
    
    </script>";
}

?>