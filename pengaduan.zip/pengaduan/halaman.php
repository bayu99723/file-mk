<?php
if(isset($_GET['url'])){
	switch ($_GET['url']) {
		case 'tulis-pengaduan':
			include 'tulis-pengaduan.php';
			break;
		case 'lihat-pengaduan':
		include 'lihat-pengaduan.php';
		break;
		default:
		echo "Halaman Tidak Ditemukan";
		break;
	}
}else{
	echo "Selamat Datang Di Aplikasi Pengaduan Masyarakat Dimana Aplikasi Ini Dibuat Untuk Melaporkan Tindakan Yang Menyimpang Dari Ketentuan.<br>";
	echo "Anda Login Sebagai: ".$_SESSION['nama'];
}