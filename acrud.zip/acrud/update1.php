<?php
	include "koneksi.php";

	$ide = $_POST['update'];

	$sql = "SELECT * FROM siswa WHERE id = '$ide'";
	$query = mysqli_query($link, $sql) or die(mysql_error($link));

	if (mysqli_num_rows($query) > 0) {
		$data = mysqli_fetch_array($query);
	}
	?>