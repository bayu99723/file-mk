<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Update</title>
</head>
<body>
	<?php
	include "koneksi.php";

	$ide = $_GET['update_id'];

	$sql = "SELECT * FROM siswa WHERE id = '$ide'";
	$query = mysqli_query($link, $sql) or die(mysql_error($link));

	if (mysqli_num_rows($query) > 0) {
		$data = mysqli_fetch_array($query);
	}
	?>

	<form action="update.php" method="post">
		<input type="hidden" name="id" value="<?php echo $data["id"]; ?>">

		<table>
			<tr>
				<td>Nama Lengkap</td>
				<td>:</td>
				<td><input type="text" name="nama" value="<?php echo $data["nama"] ?>"></td>
			</tr>
			<tr>
				<td>NISN</td>
				<td>:</td>
				<td><input type="text" name="nisn" value="<?php echo $data["nisn"] ?>"></td>
			</tr>
			<tr>
				<td></td>
				<td></td>
				<td><input type="submit" name="edit" value="Update"></td>
			</tr>
		</table>
	</form>
</body>
</html>