<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Seluruh Data</title>
</head>
<body>
	<table border="1" align="center" style="margin-top: 200px;">
		<thead>
			<tr>
				<th>Nama Lengkap</th>
				<th>NISN</th>
				<th>tanggal</th>
				<th>button</th>
			</tr>
		</thead>
		<tbody align="center">
			<?php
			include "koneksi.php";

			$sql = "SELECT * FROM siswa ORDER BY id DESC";
			$query = mysqli_query($link, $sql) or die(mysql_error($link));

			$no = 1;

			while ($data = mysqli_fetch_array($query)) {
				$id = $data["id"];
				$nm = $data["nama"];
				$nis = $data["nisn"];
				$tgl = $data["tanggal"];

				echo "<tr>
				<td>$nm</td>
				<td>$nis</td>
				<td>$tgl</td>
				<td>
				<a href='update.php?update_id=$id'>Update</a>
				<a href='delete.php?delete_id=$id'>Delete</a>
				</td>";
				$no++;
			}
			?>
				</tr>
		</tbody>
	</table>
</body>
</html>