<?php
	include "koneksi.php";

	$idh = $_GET['delete_id'];

	$sql = "DELETE FROM siswa WHERE id='$idh'";
	$query = mysqli_query($link, $sql) or die(mysql_error($link));

	if($query) {
		echo "Berhasil di Hapus!";
		header('location:tampil_data.php');
	} else {
		echo "Error :".$sql."<br>".mysql_error($link);
	}
	mysql_close($link);
?>