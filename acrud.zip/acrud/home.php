<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Daftar Siswa</title>
	<style>
		.wrapper {
            width: 350px;
            padding: 20px;
            margin-top: 124px;
            margin-left: 500px;
            border: 2px solid black;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.5);
        }
	</style>
</head>
<body>
	<div class="wrapper">
	<h2>Input Data</h2>
	<form action="insert.php" method="post">
	<table>
		<tr>
			<td>Nama lengkap</td>
			<td>:</td>
			<td><input type="text" name="nama"></td>
		</tr>
		<tr>
			<td>NISN</td>
			<td>:</td>
			<td><input type="number" name="nisn"></td>
		</tr>
		<tr>
			<td></td>
			<td></td>
			<td>
				<input type="submit" name="kirim" value="simpan">
				<input type="reset" name="clear" value="batal">
			</td>
		</tr>
	</table>
	</form>
</div>
</body>
</html>