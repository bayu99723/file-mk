<?php 
include "koneksi.php";

$nm = $_POST['nama'];
$nis = $_POST['nisn'];

date_default_timezone_set("Asia/Jakarta");

$tgl = date("Y:m:d");

$sql = "INSERT INTO siswa (nama, nisn, tanggal) values ('$nm', '$nis', '$tgl')";
$query = mysqli_query ($link, $sql) or die(mysql_error());

if ($query) {
	echo "Data Berhasil di Insert";
	header('location:tampil_data.php');
}
else {
	echo "Error :".$sql."<br>".mysql_error($link);
}

mysql_close($link);
?>